import React, {useState, useEffect} from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Employee from './employee';
import Employees from './employees';

function App() {
  const [employees, setEmployees] = useState([]);

  useEffect(() => {
    fetch('/employees')
    .then(resp => resp.json())
    .then(emp => {
      setEmployees(emp);
    })
  }, []);

  return (
    <Router>
      <Routes>
        {
          (
            employees.persons &&
            <Route 
              exact 
              path="/" 
              element={<Employees entity={employees.persons} />}  
            /> 
          )
        }
        {
          (
            employees.persons &&
            employees.persons.map(
              (emp, i) => 
                <Route 
                  key={i}
                  exact 
                  path={"/" + emp.name}
                  element={<Employee entity={emp} />}  
                />
              )
          )
        }
        
          
      </Routes>
    </Router>
  );
}

export default App;
