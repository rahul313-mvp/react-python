import React from 'react';
import {Link} from 'react-router-dom';

function Employees(entity) {

  return (
    <nav>
        {
            entity &&
            entity.entity.map((emp, i) => (
                <Link key={i} to={"/" + emp.name}>
                    <p style={{color: "Blue"}}>{emp.name}</p>
                </Link>
            ))
        }
    </nav>
  );
}

export default Employees;
