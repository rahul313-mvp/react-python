import React, {useState, useEffect} from 'react';

function Employee(entity) {
  
    return (
      <div>
        <p>Name: {entity.entity.name}</p>
        <p>Designation: {entity.entity.designation}</p>
      </div>
    );
  }
  
export default Employee;
