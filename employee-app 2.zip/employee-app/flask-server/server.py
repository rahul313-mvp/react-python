from flask import Flask

app = Flask(__name__)

@app.route("/employees")
def employees():
    return {
        "persons":[
            {"name":"Mike","designation":"PM"},
            {"name":"Albert","designation":"Director"},
            {"name":"Jimmy","designation":"Analyst"},
            {"name":"Henan","designation":"Frontend Developer"},
            {"name":"Egan","designation":"Backend Developer"},
            {"name":"Matt","designation":"Senior Engineer"},
            {"name":"Ravi","designation":"Senior Engineer"},
            {"name":"Colus","designation":"General Engineer"},
        ]
    }

if __name__ == "__main__":
    app.run(debug=True)
